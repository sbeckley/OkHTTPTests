package com.example.okhttptest;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;

import com.fasterxml.jackson.core.JsonParser;
import com.json.parsers.JSONParser;
import com.json.parsers.JsonParserFactory;
import com.squareup.okhttp.OkHttpClient;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;
import android.widget.TextView;

public class OkHTTPMainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		Log.v("TEST", "created");
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_ok_httpmain);
		
		RetreiveDataTask task = new RetreiveDataTask();
		task.execute("http://10.0.2.2:3000/sparks.json");
		
	}
	
	class RetreiveDataTask extends AsyncTask<String, Void, String> {
		
		String TAG = "RetreiveDataTask";
		

        OkHttpClient client = new OkHttpClient();
		
        private Exception exception;
        
        protected String doInBackground(String... urls) {
        	Log.v("TEST", "doing in background");
            try {
            	return get(new URL(urls[0]));
            	
            } catch (Exception e) {
                this.exception = e;
                Log.e(TAG, "Exception: "+e);
                return null;
            }
        }

        protected void onPostExecute(String data) {
        	Log.d(TAG, "=> "+data);
        	TextView t = (TextView)findViewById(R.id.editText1);
        	t.setText(data);
        	/*try {
				parseData(data);
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
        }
        
        //PARSE DATA
        
        @SuppressWarnings("unused")
		void parseData(String data) throws JSONException {
        	final String TAG_ID = "id";
        	final String SPARK_TYPE = "spark_type";
        	final String CONTENT_TYPE = "content_type";
        	final String CONTENT_HASH = "content_hash";
        	final String CONTENT = "content";
        	final String CREATED_AT = "created_at";
        	final String UPDATED_AT = "updated_at";
        	// Creating JSON Parser instance
        	JSONParser jParser = new JSONParser();
        	 
        	// getting JSON string from URL
        	JSONObject json = new JSONObject(data);
        	 
        	try {
				// Storing each json item in variable
				String id = json.getString(TAG_ID);
				String sparkType = json.getString(SPARK_TYPE);
				String contentType = json.getString(CONTENT_TYPE);
				String content = json.getString(CONTENT);
				String createdAt = json.getString(CREATED_AT);
				String updatedAt = json.getString(UPDATED_AT);
				String contentHash = json.getString(CONTENT_HASH); 
				System.out.print(content);
        	} catch (JSONException e) {
        	    e.printStackTrace();
        	}
        }
        
        String get(URL url) throws IOException {
          HttpURLConnection connection = client.open(url);
          InputStream in = null;
          try {
            // Read the response.
            in = connection.getInputStream();
            byte[] response = readFully(in);
            return new String(response, "UTF-8");
          } finally {
            if (in != null) in.close();
          }
        }
        
        byte[] readFully(InputStream in) throws IOException {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            for (int count; (count = in.read(buffer)) != -1; ) {
              out.write(buffer, 0, count);
            }
            return out.toByteArray();
          }
        
     }
	

}
